export class Recipe{

public Name:string;
public description:string;
public imagePath:string;

constructor(name:string, desc:string, image:string){
    this.Name=name;
    this.description=desc;
    this.imagePath=image;
}
}